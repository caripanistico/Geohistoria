Mongo URI puesto esta en localhost, con una base de datos llamada MyDatabase, y una colección llamada Files

Para probar otra base de datos LOCAL, seguir la misma estructura, localhost->[DATABASE]->[COLLECTIOn]

Para correr localmente, instalar MONGODB Community Server.


# How to install and run back-end

> pip install -r requirements.txt

> export FLASK_APP=app

> flask run
